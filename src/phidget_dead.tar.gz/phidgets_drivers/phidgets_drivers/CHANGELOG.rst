^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package phidgets_drivers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.7 (2018-09-18)
------------------

0.7.6 (2018-08-09)
------------------

0.7.5 (2018-01-31)
------------------

0.7.4 (2017-10-04)
------------------
* Add phidgets_high_speed_encoder to metapackage
* Contributors: Jose Luis Blanco-Claraco, Martin Günther

0.7.3 (2017-06-30)
------------------

0.7.2 (2017-06-02)
------------------

0.7.1 (2017-05-22)
------------------

0.7.0 (2017-02-17)
------------------
* Remove phidgets_ir package
  It was a stub anyway. If somebody has such a device and cares to expose
  the data via ROS topics, this can be revived.
* Contributors: Martin Günther

0.2.3 (2017-02-17)
------------------
* Update package.xml meta info
* Contributors: Martin Günther

0.2.2 (2015-03-23)
------------------

0.2.1 (2015-01-15)
------------------
* phidgets_drivers: removed phidgets_c_api dependency
* Updated version, maintainer and author information
* Deleted comments within files of all packages
* phidgets_drivers: converted stack into metapackage
* Contributors: Murilo FM
