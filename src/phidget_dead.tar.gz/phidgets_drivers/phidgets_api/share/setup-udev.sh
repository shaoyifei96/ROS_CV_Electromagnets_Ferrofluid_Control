sudo cp udev/99-phidgets.rules /etc/udev/rules.d/ 
echo "Phidgets udev rules file has been copied to /etc/udev/rules.d/"
