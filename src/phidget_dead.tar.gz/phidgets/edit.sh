emacs src/*.cpp src/*.h CMakeLists.txt manifest.xml srv/*.srv msg/*.msg
